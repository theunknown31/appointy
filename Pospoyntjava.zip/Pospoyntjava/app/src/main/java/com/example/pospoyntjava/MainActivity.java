package com.example.pospoyntjava;



import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.JsResult;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.Toast;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.Arrays;
import java.util.Collections;
import java.util.UUID;

import co.poynt.api.model.CurrencyAmount;
import co.poynt.api.model.Product;
import co.poynt.api.model.ProductType;
import co.poynt.api.model.SelectableValue;
import co.poynt.api.model.SelectableVariation;
import co.poynt.api.model.Transaction;
import co.poynt.api.model.Variant;
import co.poynt.os.model.Intents;
import co.poynt.os.model.Payment;
import co.poynt.os.model.PaymentStatus;

import static co.poynt.os.model.ApnInfo.TAG;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.webkit.WebView;

public class MainActivity extends AppCompatActivity {
    int k=1;
    int COLLECT_PAYMENT_REQUEST=1;
    int DISPLAY_PAYMENT_REQUEST=1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        WebView webView = new WebView(getApplicationContext());
        setContentView(webView);
        webView.loadUrl("file:///android_res/raw/index.html");
//        webView.loadUrl("file:///android_res/raw/index.html");
        webView.addJavascriptInterface(new WebAppInterface(this), "AndroidInterface"); // To call methods in Android from using js in the html, AndroidInterface.showToast, AndroidInterface.getAndroidVersion etc
        WebSettings webSettings = webView.getSettings();
        webSettings.setJavaScriptEnabled(true);
        webView.setWebViewClient(new MyWebViewClient());
        webView.setWebChromeClient(new MyWebChromeClient());
//        final Button button = (Button) findViewById(R.id.button);
//        button.setOnClickListener(new View.OnClickListener() {
//            public void onClick(View v) {
//                transaction();
//            }
//        });
//        Product product = Util.createProduct();
//        Intent intent = new Intent();
//        intent.setAction(Intents.ACTION_ADD_PRODUCT_TO_CART);
//        intent.putExtra(Intents.INTENT_EXTRA_PRODUCT, product);
//        intent.putExtra(Intents.INTENT_EXTRA_QUANTITY, 2.0f);
//        startActivity(intent);

    }
    void addmyitem()
    {
        Intent listAllNumbers = new Intent(getBaseContext(), myintent.class);
        startActivity(listAllNumbers);

    }
    void removemyitem()
    {

    }
    private class MyWebViewClient extends WebViewClient {
        @Override
        public void onPageFinished (WebView view, String url) {
            //Calling a javascript function in html page
            view.loadUrl("javascript:alert(showVersion('called by Android'))");
        }
    }

    private class MyWebChromeClient extends WebChromeClient {
        @Override
        public boolean onJsAlert(WebView view, String url, String message, JsResult result) {
            Log.d("LogTag", message);
            result.confirm();
            return true;
        }
    }
   void transaction()
    {
        System.out.println("3");
        String currencyCode="USD";
        int amount =10;
        Payment payment = new Payment();
        String referenceId = UUID.randomUUID().toString();
        payment.setReferenceId(referenceId);
        payment.setAmount(amount);
        payment.setCurrency(currencyCode);

        // start Payment activity for result
        try {
            System.out.println("4");
            Intent collectPaymentIntent = new Intent(Intents.ACTION_COLLECT_PAYMENT);
            collectPaymentIntent.putExtra(Intents.INTENT_EXTRAS_PAYMENT, payment);
            startActivityForResult(collectPaymentIntent,COLLECT_PAYMENT_REQUEST);
        } catch (ActivityNotFoundException ex) {
            Log.e(TAG, "Poynt Payment Activity not found - did you install PoyntServices?", ex);
        }


    }
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        System.out.println("5");
        super.onActivityResult(requestCode, resultCode, data);
        // Check which request we're responding to
        if (requestCode == COLLECT_PAYMENT_REQUEST) {
            // Make sure the request was successful
            if (resultCode == Activity.RESULT_OK) {
                if (data != null) {
                    Payment payment = data.getParcelableExtra(Intents.INTENT_EXTRAS_PAYMENT);
                    Log.d(TAG, "Received onPaymentAction from PaymentFragment w/ Status("
                            + payment.getStatus() + ")");
                    if (payment.getStatus().equals(PaymentStatus.COMPLETED)) {
                        Toast.makeText(this, "Payment Completed", Toast.LENGTH_LONG).show();
                    } else if (payment.getStatus().equals(PaymentStatus.AUTHORIZED)) {
                        Toast.makeText(this, "Payment Authorized", Toast.LENGTH_LONG).show();
                        System.out.println(payment.getOrderId());
                        System.out.println(payment.getApplicationIndex());
                        System.out.println(payment.getTid());
                        okay();

                    } else if (payment.getStatus().equals(PaymentStatus.CANCELED)) {
                        Toast.makeText(this, "Payment Canceled", Toast.LENGTH_LONG).show();
                    } else if (payment.getStatus().equals(PaymentStatus.FAILED)) {
                        Toast.makeText(this, "Payment Failed", Toast.LENGTH_LONG).show();
                    } else if (payment.getStatus().equals(PaymentStatus.REFUNDED)) {
                        Toast.makeText(this, "Payment Refunded", Toast.LENGTH_LONG).show();
                    } else if (payment.getStatus().equals(PaymentStatus.VOIDED)) {
                        Toast.makeText(this, "Payment Voided", Toast.LENGTH_LONG).show();
                    } else {
                        Toast.makeText(this, "Payment Completed", Toast.LENGTH_LONG).show();
                    }

                    if (payment.getTransactions() != null && payment.getTransactions().size() > 0) {
                        Transaction transaction = payment.getTransactions().get(0);
//                        Gson gson = new GsonBuilder().setPrettyPrinting().create();
//                        Type transactionType = new TypeToken<Transaction>() {
//                        }.getType();
//                        Log.d(TAG,gson.toJson(transaction, transactionType));

                        System.out.println(transaction.getId());
                        transactionId=transaction.getId().toString();
                    }
                }
            } else if (resultCode == Activity.RESULT_CANCELED) {
                Toast.makeText(this, "Payment Canceled", Toast.LENGTH_LONG).show();
            }
        }



    }
    String transactionId;
    void okay()
    {
        System.out.println("6");
        try {
            Intent displayPaymentIntent = new Intent(Intents.ACTION_DISPLAY_PAYMENT);
            displayPaymentIntent.putExtra(Intents.INTENT_EXTRAS_TRANSACTION_ID, transactionId);
            startActivity(displayPaymentIntent);
        } catch (ActivityNotFoundException ex) {
            Log.e(TAG, "Poynt Payment Activity not found - did you install PoyntServices?", ex);
        }
    }
    class WebAppInterface {
        Context mContext;

        WebAppInterface(Context c) {
            mContext = c;
        }

        @JavascriptInterface
        public void additem() {
            Toast.makeText(mContext, "Added", Toast.LENGTH_SHORT).show();
            addmyitem();

        }
        @JavascriptInterface
        public void remove() {
            Toast.makeText(mContext, "Remove", Toast.LENGTH_SHORT).show();
            removemyitem();

        }
        @JavascriptInterface
        public void pay() {
            Toast.makeText(mContext, "Paid", Toast.LENGTH_SHORT).show();
            transaction();

        }


    }

}

class Util
{
    public static Product createProduct() {
        String sku = "1234567890";
        /*

    "selectableVariants": [
        {
            "selectableVariations": [
                {
                    "values": [
                        {
                            "defaultValue": true,
                            "priceDelta": {
                                "amount": 0,
                                "currency": "USD"
                            },
                            "name": "M"
                        },
                        {
                            "priceDelta": {
                                "amount": 0,
                                "currency": "USD"
                            },
                            "name": "L"
                        },
                        {
                            "priceDelta": {
                                "amount": 0,
                                "currency": "USD"
                            },
                            "name": "XL"
                        }
                    ],
                    "attribute": "Size",
                    "cardinality": "1"
                },


         */
        Product product = new Product();
        product.setName("Nike Two");
        CurrencyAmount price = new CurrencyAmount(19900l, "USD");
        product.setPrice(price);
        product.setSku(sku);
        product.setType(ProductType.SIMPLE);
        Variant variant = new Variant();
        variant.setSku(sku);

        // size options (only 1 allowed)
        SelectableVariation sizeVariation = new SelectableVariation();
        sizeVariation.setAttribute("Size");
        sizeVariation.setCardinality("1");

        SelectableValue valueM = new SelectableValue();
        valueM.setDefaultValue(true);
        valueM.setName("M");
        valueM.setPriceDelta(new CurrencyAmount(0l, "USD"));

        SelectableValue valueL = new SelectableValue();
        valueL.setName("L");
        valueL.setPriceDelta(new CurrencyAmount(0l, "USD"));

        SelectableValue valueXL = new SelectableValue();
        valueXL.setName("XL");
        valueXL.setPriceDelta(new CurrencyAmount(0l, "USD"));

        sizeVariation.setValues(Arrays.asList(valueM, valueL, valueXL));

        // color options (only 1 allowed)
        SelectableVariation colorVariation = new SelectableVariation();
        colorVariation.setAttribute("Color");
        colorVariation.setCardinality("1");

        SelectableValue colorWhite = new SelectableValue();
        colorWhite.setDefaultValue(true);
        colorWhite.setName("White");
        colorWhite.setPriceDelta(new CurrencyAmount(0l, "USD"));

        SelectableValue colorGreen = new SelectableValue();
        colorGreen.setName("Green");
        colorGreen.setPriceDelta(new CurrencyAmount(0l, "USD"));

        SelectableValue colorBlue = new SelectableValue();
        colorBlue.setName("Blue");
        colorBlue.setPriceDelta(new CurrencyAmount(0l, "USD"));

        colorVariation.setValues(Arrays.asList(colorWhite, colorGreen, colorBlue));


        variant.setSelectableVariations(Arrays.asList(sizeVariation, colorVariation));
        product.setSelectableVariants(Collections.singletonList(variant));

        return product;
    }
}
