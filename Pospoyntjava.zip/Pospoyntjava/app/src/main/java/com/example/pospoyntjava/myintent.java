package com.example.pospoyntjava;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import co.poynt.api.model.Product;
import co.poynt.os.model.Intents;

import static java.lang.System.exit;

public class myintent extends Activity {

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
addmyitem();
    }
    void addmyitem()
    {

        Product product = Util.createProduct();
        Intent intent = new Intent();
        intent.setAction(Intents.ACTION_ADD_PRODUCT_TO_CART);
        intent.putExtra(Intents.INTENT_EXTRA_PRODUCT, product);
        intent.putExtra(Intents.INTENT_EXTRA_QUANTITY, 2.0f);
        startActivity(intent);
        System.out.println("koooko");
System.exit(1);

    }
}
